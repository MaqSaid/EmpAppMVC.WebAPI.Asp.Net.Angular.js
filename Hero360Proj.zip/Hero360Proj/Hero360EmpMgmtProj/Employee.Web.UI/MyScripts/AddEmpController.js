﻿/// <reference path="\Employee.Web.UI\Scripts/angular.min.js" />

/// <reference path="\Employee.Web.UI\MyScripts/Module.js" />
/// <reference path="Services.js" />

app.controller('AddEmployeeController', function ($scope, SinglePageCRUDService) {
    $scope.EmpNo = 0;
    //Maq:The Save scope method is use to define the Hero360 Employee object and 
    //post the Employee information to the server by making call to the Service
    $scope.save = function () {
        var Employee = {
            EmpNo: $scope.EmpNo,
            EmpName: $scope.EmpName,
            Salary: $scope.Salary,
            DeptName: $scope.DeptName,
			Designation: $scope.Designation,
			DateofJoining: $scope.DateofJoining
        };
     
        var promisePost = SinglePageCRUDService.post(Employee);


        promisePost.then(function (pl) {
            $scope.EmpNo = pl.data.EmpNo;
            alert("Added Employee Details with Employee No " + pl.data.EmpNo);
        },
              function (errorPl) {
                  $scope.error = 'Failure Loading Employee Details', errorPl;
              });

    };

});