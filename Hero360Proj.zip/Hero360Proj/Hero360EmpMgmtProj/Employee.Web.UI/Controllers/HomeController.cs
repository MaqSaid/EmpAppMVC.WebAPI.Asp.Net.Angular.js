﻿/*  MAQ: Not Required for this Page
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
*/
using System.Web.Mvc;

namespace Hero360.Net.MVC.Angular.Employee.Web.UI.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Display Hero360 Info and/or Employeee Management App Info.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Show your Contract Page/Info";

            return View();
        }
    }
}