﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Hero360.Net.MVC.Angular.Employee.Web.UI.Startup))]
namespace Hero360.Net.MVC.Angular.Employee.Web.UI
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
