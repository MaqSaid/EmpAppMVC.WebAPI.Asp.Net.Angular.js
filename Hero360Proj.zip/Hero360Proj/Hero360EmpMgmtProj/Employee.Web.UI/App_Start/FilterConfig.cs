﻿using System.Web;
using System.Web.Mvc;

namespace Hero360.Net.MVC.Angular.Employee.Web.UI
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
